export declare enum Output {
    Jpg = "jpg",
    Jpeg = "jpeg",
    Png = "png",
    Webp = "webp",
    Heic = "heic",
    Avif = "avif",
    Gif = "gif"
}
