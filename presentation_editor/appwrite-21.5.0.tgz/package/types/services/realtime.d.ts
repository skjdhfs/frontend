import { Client } from '../client';
export declare type RealtimeSubscription = {
    close: () => Promise<void>;
};
export declare type RealtimeCallback<T = any> = {
    channels: Set<string>;
    callback: (event: RealtimeResponseEvent<T>) => void;
};
export declare type RealtimeResponse = {
    type: string;
    data?: any;
};
export declare type RealtimeResponseEvent<T = any> = {
    events: string[];
    channels: string[];
    timestamp: string;
    payload: T;
};
export declare type RealtimeResponseConnected = {
    channels: string[];
    user?: object;
};
export declare type RealtimeRequest = {
    type: 'authentication';
    data: {
        session: string;
    };
};
export declare enum RealtimeCode {
    NORMAL_CLOSURE = 1000,
    POLICY_VIOLATION = 1008,
    UNKNOWN_ERROR = -1
}
export declare class Realtime {
    private readonly TYPE_ERROR;
    private readonly TYPE_EVENT;
    private readonly TYPE_PONG;
    private readonly TYPE_CONNECTED;
    private readonly DEBOUNCE_MS;
    private readonly HEARTBEAT_INTERVAL;
    private client;
    private socket?;
    private activeChannels;
    private activeSubscriptions;
    private heartbeatTimer?;
    private subCallDepth;
    private reconnectAttempts;
    private subscriptionsCounter;
    private reconnect;
    private onErrorCallbacks;
    private onCloseCallbacks;
    private onOpenCallbacks;
    constructor(client: Client);
    /**
     * Register a callback function to be called when an error occurs
     *
     * @param {Function} callback - Callback function to handle errors
     * @returns {void}
     */
    onError(callback: (error?: Error, statusCode?: number) => void): void;
    /**
     * Register a callback function to be called when the connection closes
     *
     * @param {Function} callback - Callback function to handle connection close
     * @returns {void}
     */
    onClose(callback: () => void): void;
    /**
     * Register a callback function to be called when the connection opens
     *
     * @param {Function} callback - Callback function to handle connection open
     * @returns {void}
     */
    onOpen(callback: () => void): void;
    private startHeartbeat;
    private stopHeartbeat;
    private createSocket;
    private closeSocket;
    private getTimeout;
    private sleep;
    /**
     * Subscribe to a single channel
     *
     * @param {string} channel - Channel name to subscribe to
     * @param {Function} callback - Callback function to handle events
     * @returns {Promise<RealtimeSubscription>} Subscription object with close method
     */
    subscribe(channel: string, callback: (event: RealtimeResponseEvent<any>) => void): Promise<RealtimeSubscription>;
    /**
     * Subscribe to multiple channels
     *
     * @param {string[]} channels - Array of channel names to subscribe to
     * @param {Function} callback - Callback function to handle events
     * @returns {Promise<RealtimeSubscription>} Subscription object with close method
     */
    subscribe(channels: string[], callback: (event: RealtimeResponseEvent<any>) => void): Promise<RealtimeSubscription>;
    /**
     * Subscribe to a single channel with typed payload
     *
     * @param {string} channel - Channel name to subscribe to
     * @param {Function} callback - Callback function to handle events with typed payload
     * @returns {Promise<RealtimeSubscription>} Subscription object with close method
     */
    subscribe<T>(channel: string, callback: (event: RealtimeResponseEvent<T>) => void): Promise<RealtimeSubscription>;
    /**
     * Subscribe to multiple channels with typed payload
     *
     * @param {string[]} channels - Array of channel names to subscribe to
     * @param {Function} callback - Callback function to handle events with typed payload
     * @returns {Promise<RealtimeSubscription>} Subscription object with close method
     */
    subscribe<T>(channels: string[], callback: (event: RealtimeResponseEvent<T>) => void): Promise<RealtimeSubscription>;
    private cleanUp;
    private handleMessage;
    private handleResponseConnected;
    private handleResponseError;
    private handleResponseEvent;
}
